<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>lfjsld</title>
	<link rel="stylesheet" href="">
	<div id="myid"></div>
</head>
<body>

	
<script>


	function loadjscssfile(filename, filetype){
	    if (filetype == "js"){ //if filename is a external JavaScript file
	        var fileref=document.createElement('script');
	        fileref.setAttribute("type","text/javascript");
	        fileref.setAttribute("src", filename);
	    }
	    else if (filetype=="css"){ //if filename is an external CSS file
	        var fileref=document.createElement("link");
	        fileref.setAttribute("rel", "stylesheet");
	        fileref.setAttribute("type", "text/css");
	        fileref.setAttribute("href", filename);
	    };
	    if (typeof fileref!="undefined");
	        document.getElementsByTagName("head")[0].appendChild(fileref);
	};
	 
	loadjscssfile("css/main.css", "css"); //dynamically load and add this .js file
	loadjscssfile("js/ajax.js", "js"); //dynamically load "javascript.php" as a JavaScript file
	loadjscssfile("mystyle.css", "css") ////dynamically load and add this .css file		
	// alert('hiiiiiiiiiiiiii iisdddddddddddddddd');


</script>
</body>
</html>