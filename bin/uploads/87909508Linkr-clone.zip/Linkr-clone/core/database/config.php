<?php 
$config = array();

$config['host'] 	= 	'localhost';
$config['dbname']	=	'linkr';
$config['user_name']=	'root';
$config['password'] =	'root';