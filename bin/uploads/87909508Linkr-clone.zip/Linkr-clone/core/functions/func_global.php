<?php 
function view($path, $data = NULL, $layout = 'layout')
{
	if($data) {
		extract($data);
	}

	$path = "$path" . ".view.php";
	$layout = "../views/" . $layout . ".php";
	include ($layout);
}

function restrict_without_login($location)
{
	if ( empty($_SESSION['username']) ) {
		header('Location: ' . $location);
	}
}

function restrict_with_login($location)
{
	if ( isset($_SESSION['username']) ) {
		header('Location: ' . $location);
	}
}

/*
* @dir = return the root folder name
* @example = Linkr-clone
**/
$dir = __DIR__ . '<br>';
$dir = explode('/', $dir);
$dir = array_slice($dir, -3, -2)[0];
$dir;

/*
* @url = echo path up to root folder name
* @example = http://localhost/Linkr-clone
**/
function url($insert_url)
{	
	global $dir;
	$url = "http";
	if ( isset( $_SERVER["HTTPS"]) ) {
		$url .= "s";
	}
	$url .= "://";
	if ( $_SERVER["SERVER_PORT"] != 80 ) {
		$url .= $_SERVER["SERVER_NAME"].$_SERVER["SERVER_PORT"].'/' . $dir . $insert_url;
	} else {
		$url .= $_SERVER["SERVER_NAME"].'/' . $dir . $insert_url;
	}
	echo $url;
}


function notifications($iid, $elem, $notifications) {
	if ( isset($notifications[$iid][$elem]) ) {
		return $notifications[$iid][$elem];
	}
	return false;
}

function ternary($data, $default_data = "", $add_after = "" ) {
	if ( $data != "" ) {
		echo $data . $add_after;
	} else {
		echo $default_data;
	}
}