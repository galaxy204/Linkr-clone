					<div class="col-sm-12" id="header_bottom">
						
						<h1><a href="#"><i class="fa fa-envelope"></i> Messages & notifications</a></h1>
					
					</div>				
				</div>
			</div>



			<!-- start my profile area -->
			<div class="container-fluid" id="message_area">
			
			
			
				<!-- start message row -->
				<div class="row">
				
				
					<!-- start left menu -->
					<div class="col-md-2" id="message_left_menu_bar">
					
						<ul class="nav nav-pills nav-stacked">
							
							<li role="presentation" class="active"><a href="#">Inbox</a></li>
							<li role="presentation" ><a href="#">Sent</a></li>

						</ul>

						<button class="btn btn-xxs btn-primary btn-block" >New message</button>
					</div> <!-- end  left menu  -->
					
					
					<!-- start  right_form  -->
					<div class="col-md-9" id="message_body">
							

						<div class="col-sm-12" id="message_top">
							
							<div class="btn-group">
								<button class="btn btn-xs btn-white"  style="margin-bottom:4px">
									<i class="fa fa-check-square-o"></i>
								</button>
								<button class="btn btn-xs btn-white" style="margin-bottom:4px">
									<i class="fa fa-square-o"></i>
								</button>
								<button class="btn btn-xs btn-white ng-binding" style="margin-bottom:4px">Mark as read</button>
							</div>							
						
						</div>
						
						
						<div class="col-sm-12" id="message_unread">
						
							<h5>Unread (1)</h5>
							
							<table class="table table-bordered">
							
								<tbody>
									
									<tr>
									
										<td class="table_td_left" ><i class="fa fa-envelope"></i> Anna J. Gaona</td>
										<td class="table_td_right">3/3/2015</td>
									
									</tr>
								
								</tbody>
							
							</table>
						
						</div>
						<div class="col-sm-12" id="message_read">
						
						
							<h5>Read (1)</h5>
							
							<table class="table table-bordered">
							
								<tbody>
									
									<tr>
									
										<td class="table_td_left" ><i class="fa fa-envelope"></i> Anna J. Gaona</td>
										<td class="table_td_right">3/3/2015</td>
									
									</tr>
								
								</tbody>
							
							</table>						
						
						</div>
						
					
					</div>
					<!-- end  right_form  -->
				
				
				</div>
				<!-- end message row-->
			
			
			
			
			</div>
			
			<!-- end my profile area -->
			
			