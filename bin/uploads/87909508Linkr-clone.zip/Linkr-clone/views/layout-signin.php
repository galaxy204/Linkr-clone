<?php include ('../includes/header-login.php'); ?>

	<?php include $path; ?>

<?php include ('../includes/footer-login.php'); ?>