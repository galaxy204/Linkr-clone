<?php include ('../includes/header.php'); ?>

	<?php include $path; ?>

<?php include ('../includes/footer.php'); ?>