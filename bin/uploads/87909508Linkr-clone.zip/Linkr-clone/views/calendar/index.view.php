<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8' />
<link href='../core/calendar/fullcalendar.css' rel='stylesheet' />
<link href='../core/calendar/fullcalendar.print.css' rel='stylesheet' media='print' />
<script src='../core/calendar/lib/moment.min.js'></script>
<script src='../core/calendar/lib/jquery.min.js'></script>
<script src='../core/calendar/fullcalendar.js'></script>

<script>



	$(document).ready(function() {
		$('#calendar').fullCalendar({
			defaultDate: moment().format('YYYY-MM-DD'),
			editable: false,
			eventLimit: true, // allow "more" link when too many events
			events: 'json/events.json',
			eventClick: function(event) {
				
		        document.getElementById('mydiv').style.background = 'red';
		        if (event.url) {
		            return false;
		        }
		    }
		}); // end full calendar
		
	});

</script>
<style>

	body {
		margin: 40px 10px;
		padding: 0;
		font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
		font-size: 14px;
	}

	#calendar {
		max-width: 900px;
		margin: 0 auto;
	}

</style>
</head>
<body>
<script>
function loadjscssfile(filename, filetype){
    if (filetype=="js"){ //if filename is a external JavaScript file
        var fileref=document.createElement('script')
        fileref.setAttribute("type","text/javascript")
        fileref.setAttribute("src", filename)
    }
    else if (filetype=="css"){ //if filename is an external CSS file
        var fileref=document.createElement("link")
        fileref.setAttribute("rel", "stylesheet")
        fileref.setAttribute("type", "text/css")
        fileref.setAttribute("href", filename)
    }
    if (typeof fileref!="undefined")
        document.getElementsByTagName("head")[0].appendChild(fileref)
}
 
loadjscssfile("myscript.js", "js") //dynamically load and add this .js file
loadjscssfile("javascript.php", "js") //dynamically load "javascript.php" as a JavaScript file
loadjscssfile("mystyle.css", "css") ////dynamically load and add this .css file	

	</script>

	<div id='calendar'></div>


</body>
</html>