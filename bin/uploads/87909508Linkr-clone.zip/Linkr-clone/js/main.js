function _(x){
	return document.getElementById(x);
}


function restrict(elem){
	var tf = _(elem);
	var rx = new RegExp;
	if(elem == "email"){
		rx = /[' "]/gi;
	} else if(elem == "username"){
		rx = /[^a-z0-9_]/gi;
	} else if(elem == "fullname") {
		rx = /[^a-z0-9 ]/gi;
	} else if(elem == "position") {
		rx = /[^a-z0-9 .]/gi;
	} else if(elem == "organization") {
		rx = /[^a-z0-9 .]/gi;
	} else if(elem == "phone") {
		rx = /[^0-9+ ]/;
	} else if(elem == "filter") {
		rx = /[^a-z0-9.]/gi;
	}
	tf.value = tf.value.replace(rx, "");
}

function emptyElement(x){
	_(x).innerHTML = "";
}

function notification(msg) {
	_('notification').style.display = "block";
	_('notification').innerHTML = '<p>'+msg+'</p>';
	$('#notification').fadeOut(5000, queue = false);
}

function checked(elem) {
	var check = _(elem).checked;
	if ( check == true ) {
		return '1';
	} else {
		return '0';
	}
}