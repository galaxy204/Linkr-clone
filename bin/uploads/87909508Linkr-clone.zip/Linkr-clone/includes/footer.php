	</div> <!-- end main area -->

	<!-- bootstrap -->	
	<script src="http://code.jquery.com/jquery-2.1.0.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>			
	<!-- end_bootstrap -->	
	<script>
	$(document).ready(function() {

		$(window).scroll( function() {
			var myscroll = $(this).scrollTop();
			var menuHeight = $('.navbar').height();

			if ( myscroll > 0) {
				$('#header_area').css('padding-top', menuHeight + 'px');
				$('#header_top').addClass('fixed-menu');
				
			} else {
				$('#header_top').removeClass('fixed-menu');
				$('#header_area').css('padding-top', '0px');
			};
		});

		if ($(window).scroll() > 0) {
			$('#header_area').css('padding-top', menuHeight + 'px');
			$('#header_top').addClass('fixed-menu');
		};
	});	
	</script>	
		
</body>
</html>