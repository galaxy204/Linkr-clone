				<div class="copy_right">
				
					<p>&copy; 2015</p>
					
				</div><!-- end login form copy right area -->
			
			</div> <!-- end col4 -->
		
		
		</div> <!-- end row -->
	
	</div> <!-- end contianer -->
	
	
	<!-- end login form -->
	
	<!-- bootstrap -->	
	<script src="http://code.jquery.com/jquery-2.1.0.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>		
	
</body>
</html>