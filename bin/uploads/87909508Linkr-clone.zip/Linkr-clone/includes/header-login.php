<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>This is title</title>
		
		<meta content="width=device-width, initial-scale=1" name="viewport">
		
		
		<link rel="stylesheet" href="../css/bootstrap.css" />
		<link rel="stylesheet" href="../css/bootstrap.min.css" />
		<link rel="stylesheet" href="../css/main.css" />
		
		<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
		

	</head>
	<body style="background:#318BBD;">
		
		
		<!-- login form -->
		
		<div class="container-fluid" id="home_login">
		
			<div class="row">
			
				<div class="col-sm-4 col-sm-offset-4 col-xs-8 col-xs-offset-2" id="login_area">
					
					
					<!--  login form heading area-->
					
					
					<div class="login_header_area">
					
						<h2>Linkr</h2>
						<p>Enterprise Social Network</h3>
					
					</div><!-- end login form heading area-->